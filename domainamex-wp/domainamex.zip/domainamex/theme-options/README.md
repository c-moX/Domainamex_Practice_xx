### :warning: All development has been moved to https://github.com/Codestar/codestar-framework repo effective from January 12th 2019 :warning:

We will remove this older version after few months. Make sure you get backup of older versions.

---

[![Codestar Framework](https://raw.githubusercontent.com/Codestar/codestar-framework-archived/master/assets/images/banner.png)](https://github.com/Codestar/codestar-framework)

## Hi everyone

Sorry, this version has been archived. We will not support old version from now on. If you have any questions, please feel free to ask routewp[at]gmail[dot]com

## Whats new version ?

I was working on two versions (Free and Premium versions) since long time ago. Because I want to speed up to this project. "Premium version" is a kind of a donate. click to visit new version: https://github.com/Codestar/codestar-framework

**Free version** offers only Admin Option Framework.

**Premium vesion** offers Admin Option Framework, Metabox Option Framework, Customize Option Framework, Taxonomy Option Framework and Shortcode Generator Framework.

Regards, Codestar
